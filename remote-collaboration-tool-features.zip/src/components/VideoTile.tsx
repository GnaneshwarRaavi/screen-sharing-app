import { useEffect, useRef } from "react";
import { MicOff, VideoOff, Monitor } from "lucide-react";
import type { PeerInfo } from "../types";

interface VideoTileProps {
  stream: MediaStream | null;
  info: PeerInfo;
  isLocal?: boolean;
  isLarge?: boolean;
  color?: string;
}

export function VideoTile({ stream, info, isLocal, isLarge, color = "#a78bfa" }: VideoTileProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  const showVideo = stream && stream.getVideoTracks().some((t) => t.enabled);
  const initials = info.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <div
      className={`relative rounded-2xl overflow-hidden bg-gradient-to-br from-slate-800 to-slate-900 ${
        isLarge ? "aspect-video" : "aspect-video"
      } ring-1 ring-white/10 shadow-xl`}
    >
      {showVideo ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted={isLocal}
          className={`w-full h-full object-cover ${isLocal ? "scale-x-[-1]" : ""}`}
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            className="w-20 h-20 rounded-full flex items-center justify-center text-2xl font-bold shadow-xl"
            style={{
              background: `linear-gradient(135deg, ${color}, ${color}aa)`,
              boxShadow: `0 0 40px ${color}40`,
            }}
          >
            {initials || "?"}
          </div>
        </div>
      )}

      {/* Status badges */}
      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/60 backdrop-blur text-white text-sm font-medium max-w-[70%] truncate">
          {info.isScreenSharing && <Monitor className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
          <span className="truncate">{isLocal ? `${info.name} (you)` : info.name}</span>
        </div>
        <div className="flex gap-1.5">
          {!info.hasAudio && (
            <div className="w-8 h-8 rounded-lg bg-red-500/80 backdrop-blur flex items-center justify-center">
              <MicOff className="w-4 h-4" />
            </div>
          )}
          {!info.hasVideo && (
            <div className="w-8 h-8 rounded-lg bg-red-500/80 backdrop-blur flex items-center justify-center">
              <VideoOff className="w-4 h-4" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
