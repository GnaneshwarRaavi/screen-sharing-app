import { useState } from "react";
import { Video, Users, Copy, Sparkles, ArrowRight } from "lucide-react";
import { generateRoomId } from "../hooks/usePeer";

interface LobbyProps {
  onJoin: (roomId: string, name: string, role: "host" | "guest") => void;
}

export function Lobby({ onJoin }: LobbyProps) {
  const [mode, setMode] = useState<"choose" | "create" | "join">("choose");
  const [name, setName] = useState("");
  const [roomId, setRoomId] = useState(() => generateRoomId());
  const [joinCode, setJoinCode] = useState("");

  const canCreate = name.trim().length >= 2;
  const canJoin = name.trim().length >= 2 && joinCode.trim().length >= 4;

  if (mode === "choose") {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white relative overflow-hidden">
        {/* Animated bg */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-violet-600/30 blur-3xl animate-pulse" />
          <div className="absolute top-1/3 -right-40 w-[30rem] h-[30rem] rounded-full bg-fuchsia-600/20 blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
          <div className="absolute -bottom-40 left-1/3 w-[28rem] h-[28rem] rounded-full bg-indigo-600/20 blur-3xl animate-pulse" style={{ animationDelay: "2s" }} />
        </div>

        <div className="relative max-w-5xl mx-auto px-6 py-12 md:py-20">
          <div className="flex items-center gap-3 mb-16">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600 flex items-center justify-center shadow-lg shadow-violet-900/50">
              <Sparkles className="w-6 h-6" />
            </div>
            <span className="text-xl font-bold tracking-tight">Huddle</span>
          </div>

          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 bg-gradient-to-br from-white via-violet-200 to-fuchsia-300 bg-clip-text text-transparent">
              Jump into a room.<br />Collaborate live.
            </h1>
            <p className="text-lg text-white/60 max-w-xl mx-auto">
              Video calls, screen sharing, live chat and a shared cursor — all peer-to-peer in your browser.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-5 max-w-3xl mx-auto">
            <button
              onClick={() => setMode("create")}
              className="group relative rounded-2xl p-8 text-left bg-gradient-to-br from-violet-600/20 to-fuchsia-600/10 border border-white/10 hover:border-violet-400/50 transition-all hover:-translate-y-1"
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600 flex items-center justify-center mb-5 shadow-lg shadow-violet-900/50">
                <Video className="w-6 h-6" />
              </div>
              <h3 className="text-2xl font-semibold mb-2">Start a room</h3>
              <p className="text-white/60 mb-6">Create a code and invite others to join you.</p>
              <span className="inline-flex items-center gap-1 text-violet-300 font-medium">
                Create now <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
            </button>

            <button
              onClick={() => setMode("join")}
              className="group relative rounded-2xl p-8 text-left bg-white/5 border border-white/10 hover:border-white/30 transition-all hover:-translate-y-1"
            >
              <div className="w-12 h-12 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center mb-5">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-2xl font-semibold mb-2">Join a room</h3>
              <p className="text-white/60 mb-6">Enter the code you were given to jump in.</p>
              <span className="inline-flex items-center gap-1 text-white/80 font-medium">
                Enter code <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white flex items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-violet-600/20 blur-3xl" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 rounded-full bg-fuchsia-600/20 blur-3xl" />

      <div className="relative w-full max-w-md bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 shadow-2xl">
        <button
          onClick={() => setMode("choose")}
          className="text-sm text-white/50 hover:text-white mb-6"
        >
          ← Back
        </button>

        <h2 className="text-3xl font-bold mb-2">
          {mode === "create" ? "Start a room" : "Join a room"}
        </h2>
        <p className="text-white/50 mb-8">
          {mode === "create"
            ? "Set your name and share the code with others."
            : "Enter your name and the room code."}
        </p>

        <div className="space-y-5">
          <div>
            <label className="block text-sm text-white/60 mb-2">Your name</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Alex"
              className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-violet-400 focus:outline-none transition"
              autoFocus
            />
          </div>

          {mode === "create" ? (
            <div>
              <label className="block text-sm text-white/60 mb-2">Room code</label>
              <div className="flex gap-2">
                <div className="flex-1 px-4 py-3 rounded-xl bg-gradient-to-r from-violet-500/20 to-fuchsia-500/10 border border-violet-400/40 text-2xl font-mono font-bold tracking-[0.3em] text-center">
                  {roomId}
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(roomId);
                  }}
                  className="px-4 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 transition"
                  title="Copy code"
                >
                  <Copy className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setRoomId(generateRoomId())}
                  className="px-4 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 transition text-sm"
                  title="Regenerate"
                >
                  ↻
                </button>
              </div>
            </div>
          ) : (
            <div>
              <label className="block text-sm text-white/60 mb-2">Room code</label>
              <input
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                placeholder="ABCDEF"
                maxLength={8}
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-violet-400 focus:outline-none transition text-2xl font-mono font-bold tracking-[0.3em] text-center"
              />
            </div>
          )}

          <button
            disabled={mode === "create" ? !canCreate : !canJoin}
            onClick={() =>
              onJoin(
                mode === "create" ? roomId : joinCode,
                name.trim(),
                mode === "create" ? "host" : "guest"
              )
            }
            className="w-full py-4 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-600 font-semibold hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed transition shadow-lg shadow-violet-900/50"
          >
            {mode === "create" ? "Create room" : "Join room"}
          </button>
        </div>
      </div>
    </div>
  );
}
