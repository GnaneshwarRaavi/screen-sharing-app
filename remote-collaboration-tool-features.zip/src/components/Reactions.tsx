import type { Reaction } from "../types";

interface ReactionsProps {
  reactions: Reaction[];
}

export function ReactionsOverlay({ reactions }: ReactionsProps) {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-30">
      {reactions.map((r, i) => {
        // Spread across the bottom with a slight random offset
        const left = ((hashCode(r.id) & 0xffff) % 90) + 5;
        const delay = (i % 5) * 0.08;
        return (
          <div
            key={r.id}
            className="absolute text-4xl animate-float-up"
            style={{
              left: `${left}%`,
              bottom: "10%",
              animationDelay: `${delay}s`,
            }}
          >
            <div className="relative">
              <span>{r.emoji}</span>
              <div className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-xs font-medium text-white bg-black/60 backdrop-blur px-2 py-0.5 rounded whitespace-nowrap">
                {r.name}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

const EMOJIS = ["👍", "❤️", "🎉", "🔥", "😂", "👏", "💯", "✨"];

export function ReactionBar({ onReact }: { onReact: (emoji: string) => void }) {
  return (
    <div className="flex gap-1 p-1 rounded-full bg-white/5 border border-white/10 backdrop-blur">
      {EMOJIS.map((e) => (
        <button
          key={e}
          onClick={() => onReact(e)}
          className="w-9 h-9 rounded-full hover:bg-white/10 hover:scale-125 transition flex items-center justify-center text-lg"
          title={`React with ${e}`}
        >
          {e}
        </button>
      ))}
    </div>
  );
}

function hashCode(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return h;
}
