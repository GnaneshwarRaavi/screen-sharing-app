import { useEffect, useRef, useState } from "react";
import {
  Send, Smile, X, Trash2, MessageSquare, List, Users,
  LogIn, LogOut, Monitor, MonitorOff, Hand, MousePointer2,
  MicOff, Mic, Sparkles,
} from "lucide-react";
import type { ActivityEvent, ChatMessage, PeerInfo } from "../types";

type Tab = "chat" | "activity" | "people";

interface SidebarProps {
  tab: Tab;
  onTabChange: (t: Tab) => void;
  onClose: () => void;
  messages: ChatMessage[];
  activity: ActivityEvent[];
  participants: Array<{ info: PeerInfo; isLocal: boolean; color: string }>;
  onSendChat: (text: string) => void;
  onClearHistory: () => void;
  myName: string;
  myId: string;
}

export function Sidebar(props: SidebarProps) {
  return (
    <div className="flex flex-col h-full bg-[#0b0b14] border-l border-white/10">
      <div className="flex items-center justify-between p-3 border-b border-white/10">
        <div className="flex gap-1 bg-white/5 rounded-lg p-1">
          <TabBtn active={props.tab === "chat"} onClick={() => props.onTabChange("chat")} icon={<MessageSquare className="w-4 h-4" />} label="Chat" count={props.messages.length} />
          <TabBtn active={props.tab === "activity"} onClick={() => props.onTabChange("activity")} icon={<List className="w-4 h-4" />} label="Activity" count={props.activity.length} />
          <TabBtn active={props.tab === "people"} onClick={() => props.onTabChange("people")} icon={<Users className="w-4 h-4" />} label="People" count={props.participants.length} />
        </div>
        <button onClick={props.onClose} className="w-8 h-8 rounded-lg hover:bg-white/10 flex items-center justify-center text-white/60 hover:text-white">
          <X className="w-4 h-4" />
        </button>
      </div>

      {props.tab === "chat" && (
        <ChatTab
          messages={props.messages}
          onSend={props.onSendChat}
          onClear={props.onClearHistory}
          myName={props.myName}
        />
      )}
      {props.tab === "activity" && (
        <ActivityTab activity={props.activity} onClear={props.onClearHistory} />
      )}
      {props.tab === "people" && <PeopleTab participants={props.participants} />}
    </div>
  );
}

function TabBtn({ active, onClick, icon, label, count }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string; count: number }) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition ${
        active ? "bg-white/10 text-white" : "text-white/50 hover:text-white"
      }`}
    >
      {icon}
      {label}
      {count > 0 && (
        <span className={`text-[10px] px-1.5 rounded-full ${active ? "bg-violet-500/30 text-violet-200" : "bg-white/10 text-white/60"}`}>
          {count > 99 ? "99+" : count}
        </span>
      )}
    </button>
  );
}

function ChatTab({
  messages, onSend, onClear, myName,
}: { messages: ChatMessage[]; onSend: (t: string) => void; onClear: () => void; myName: string }) {
  const [text, setText] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!text.trim()) return;
    onSend(text.trim());
    setText("");
  };

  return (
    <>
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/5">
        <span className="text-xs text-white/40">
          {messages.length} message{messages.length === 1 ? "" : "s"} · saved locally
        </span>
        <button
          onClick={() => {
            if (confirm("Clear chat & activity history for this room?")) onClear();
          }}
          className="text-xs text-white/40 hover:text-red-400 flex items-center gap-1 transition"
        >
          <Trash2 className="w-3 h-3" /> Clear
        </button>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 && (
          <div className="text-center text-white/40 text-sm py-12">
            <Smile className="w-8 h-8 mx-auto mb-2 opacity-50" />
            Say hi to break the ice!
          </div>
        )}
        {messages.map((m) => {
          const isMe = m.sender === "me" || m.senderName === myName;
          if (m.system) {
            return (
              <div key={m.id} className="text-center text-xs text-white/40 py-1 italic">
                {m.text}
              </div>
            );
          }
          return (
            <div key={m.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[85%] flex flex-col ${isMe ? "items-end" : "items-start"}`}>
                {!isMe && <span className="text-xs text-white/50 mb-1 px-1">{m.senderName}</span>}
                <div
                  className={`px-3 py-2 rounded-2xl text-sm break-words ${
                    isMe
                      ? "bg-gradient-to-r from-violet-500 to-fuchsia-600 text-white rounded-br-sm"
                      : "bg-white/10 text-white rounded-bl-sm"
                  }`}
                >
                  {m.text}
                </div>
                <span className="text-[10px] text-white/30 mt-1 px-1">
                  {new Date(m.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
            </div>
          );
        })}
      </div>
      <div className="p-3 border-t border-white/10">
        <div className="flex gap-2 bg-white/5 rounded-xl p-1.5">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Type a message..."
            className="flex-1 bg-transparent px-3 py-2 text-sm text-white placeholder-white/40 focus:outline-none"
          />
          <button
            onClick={handleSend}
            disabled={!text.trim()}
            className="w-9 h-9 rounded-lg bg-gradient-to-r from-violet-500 to-fuchsia-600 flex items-center justify-center disabled:opacity-30 hover:opacity-90 transition"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </>
  );
}

function activityIcon(type: ActivityEvent["type"]) {
  switch (type) {
    case "join": return <LogIn className="w-3.5 h-3.5 text-emerald-400" />;
    case "leave": return <LogOut className="w-3.5 h-3.5 text-white/50" />;
    case "share-start": return <Monitor className="w-3.5 h-3.5 text-violet-400" />;
    case "share-stop": return <MonitorOff className="w-3.5 h-3.5 text-white/50" />;
    case "hand-raise": return <Hand className="w-3.5 h-3.5 text-amber-400" />;
    case "hand-lower": return <Hand className="w-3.5 h-3.5 text-white/40" />;
    case "control-request": return <MousePointer2 className="w-3.5 h-3.5 text-sky-400" />;
    case "control-granted": return <MousePointer2 className="w-3.5 h-3.5 text-emerald-400" />;
    case "control-revoked": return <MousePointer2 className="w-3.5 h-3.5 text-red-400" />;
    case "reaction": return <Sparkles className="w-3.5 h-3.5 text-pink-400" />;
    case "mute": return <MicOff className="w-3.5 h-3.5 text-red-400" />;
    case "unmute": return <Mic className="w-3.5 h-3.5 text-emerald-400" />;
  }
}

function activityText(e: ActivityEvent) {
  switch (e.type) {
    case "join": return `${e.actorName} joined the room`;
    case "leave": return `${e.actorName} left`;
    case "share-start": return `${e.actorName} started sharing their screen`;
    case "share-stop": return `${e.actorName} stopped sharing`;
    case "hand-raise": return `${e.actorName} raised their hand ✋`;
    case "hand-lower": return `${e.actorName} lowered their hand`;
    case "control-request": return `${e.actorName} requested control ${e.detail || ""}`;
    case "control-granted": return `${e.actorName} enabled remote control`;
    case "control-revoked": return `${e.actorName} disabled remote control`;
    case "reaction": return `${e.actorName} reacted ${e.detail || ""}`;
    case "mute": return `${e.actorName} muted`;
    case "unmute": return `${e.actorName} unmuted`;
  }
}

function ActivityTab({ activity, onClear }: { activity: ActivityEvent[]; onClear: () => void }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [activity]);

  return (
    <>
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/5">
        <span className="text-xs text-white/40">{activity.length} events · saved locally</span>
        <button
          onClick={() => {
            if (confirm("Clear all activity history?")) onClear();
          }}
          className="text-xs text-white/40 hover:text-red-400 flex items-center gap-1 transition"
        >
          <Trash2 className="w-3 h-3" /> Clear
        </button>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-3">
        {activity.length === 0 && (
          <div className="text-center text-white/40 text-sm py-12">
            <List className="w-8 h-8 mx-auto mb-2 opacity-50" />
            Activity will appear here
          </div>
        )}
        <div className="space-y-1">
          {activity.map((e) => (
            <div key={e.id} className="flex items-start gap-2.5 p-2 rounded-lg hover:bg-white/5 transition">
              <div className="w-7 h-7 rounded-full bg-white/5 border border-white/10 flex items-center justify-center shrink-0 mt-0.5">
                {activityIcon(e.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-white/90 break-words">{activityText(e)}</div>
                <div className="text-[10px] text-white/40 mt-0.5">
                  {new Date(e.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

function PeopleTab({ participants }: { participants: Array<{ info: PeerInfo; isLocal: boolean; color: string }> }) {
  return (
    <div className="flex-1 overflow-y-auto p-3">
      <div className="text-xs text-white/40 px-2 py-2">
        {participants.length} participant{participants.length === 1 ? "" : "s"}
      </div>
      <div className="space-y-1">
        {participants.map((p) => {
          const initials = p.info.name
            .split(" ")
            .map((n) => n[0])
            .join("")
            .slice(0, 2)
            .toUpperCase();
          return (
            <div key={p.info.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 transition">
              <div
                className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
                style={{ background: `linear-gradient(135deg, ${p.color}, ${p.color}aa)` }}
              >
                {initials || "?"}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-white truncate flex items-center gap-1.5">
                  {p.info.name}
                  {p.isLocal && <span className="text-[10px] text-white/50">(you)</span>}
                  {p.info.isHost && (
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-violet-500/20 text-violet-200 border border-violet-500/30">HOST</span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-[10px] text-white/50">
                  <span className="flex items-center gap-0.5">
                    {p.info.hasAudio ? <Mic className="w-3 h-3" /> : <MicOff className="w-3 h-3 text-red-400" />}
                  </span>
                  <span>{p.info.hasVideo ? "Video on" : "Video off"}</span>
                  {p.info.isScreenSharing && <span className="text-emerald-400">• Sharing</span>}
                  {p.info.isHandRaised && <span className="text-amber-400">✋ Raised</span>}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
