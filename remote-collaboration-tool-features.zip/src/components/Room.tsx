import { useEffect, useMemo, useRef, useState } from "react";
import {
  Mic, MicOff, Video, VideoOff, MonitorUp, Monitor, Phone,
  MessageSquare, Users, Copy, MousePointer2, Sparkles, Hand, Shield,
  ShieldOff,
} from "lucide-react";
import { usePeer } from "../hooks/usePeer";
import { VideoTile } from "./VideoTile";
import { Sidebar } from "./Sidebar";
import { ReactionsOverlay, ReactionBar } from "./Reactions";
import type { ClickPayload, CursorPayload, PeerInfo } from "../types";

interface RoomProps {
  roomId: string;
  myName: string;
  role: "host" | "guest";
  onLeave: () => void;
}

const CURSOR_COLORS: Record<string, string> = {};
let colorIdx = 0;
const PALETTE = ["#f472b6", "#60a5fa", "#34d399", "#fbbf24", "#a78bfa", "#fb7185", "#22d3ee", "#f97316"];
function colorFor(name: string) {
  if (!CURSOR_COLORS[name]) {
    CURSOR_COLORS[name] = PALETTE[colorIdx % PALETTE.length];
    colorIdx++;
  }
  return CURSOR_COLORS[name];
}

type TabKind = "chat" | "activity" | "people";

export function Room({ roomId, myName, role, onLeave }: RoomProps) {
  const peer = usePeer({ roomId, myName, role });
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [tab, setTab] = useState<TabKind>("chat");
  const [pointerMode, setPointerMode] = useState(false);
  const [controlMode, setControlMode] = useState(false);
  const [startError, setStartError] = useState("");
  const [copied, setCopied] = useState(false);
  const stageRef = useRef<HTMLDivElement>(null);
  const lastCursorSent = useRef(0);

  // Start camera on mount
  useEffect(() => {
    peer.startCamera().then((ok) => {
      if (!ok) setStartError("Camera/mic unavailable. You can still share screen & chat.");
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Find the screen sharer
  const sharerInfo = useMemo<PeerInfo | null>(() => {
    if (peer.isScreenSharing) {
      return {
        id: peer.myId,
        name: myName,
        hasVideo: true,
        hasAudio: !peer.isMuted,
        isScreenSharing: true,
        isHost: role === "host",
        isHandRaised: false,
      };
    }
    for (const [, p] of peer.peers) {
      if (p.info.isScreenSharing) return p.info;
    }
    return null;
  }, [peer.isScreenSharing, peer.peers, peer.myId, peer.isMuted, myName, role]);

  const sharerStream = useMemo<MediaStream | null>(() => {
    if (peer.isScreenSharing) return peer.localStream;
    for (const [, p] of peer.peers) {
      if (p.info.isScreenSharing) return p.stream;
    }
    return null;
  }, [peer.isScreenSharing, peer.localStream, peer.peers]);

  // All participants (self + others)
  const allParticipants = useMemo(() => {
    const list: Array<{ info: PeerInfo; stream: MediaStream | null; isLocal: boolean; color: string }> = [
      {
        info: {
          id: peer.myId,
          name: myName,
          hasVideo: !peer.isVideoOff,
          hasAudio: !peer.isMuted,
          isScreenSharing: peer.isScreenSharing,
          isHost: role === "host",
          isHandRaised: peer.isHandRaised,
        },
        stream: peer.localStream,
        isLocal: true,
        color: peer.myColor,
      },
    ];
    peer.peers.forEach((p) => {
      list.push({
        info: p.info,
        stream: p.stream,
        isLocal: false,
        color: colorFor(p.info.id),
      });
    });
    return list;
  }, [peer, myName, role]);

  const participantsWithoutSharer = sharerInfo
    ? allParticipants.filter((p) => p.info.id !== sharerInfo.id)
    : allParticipants;

  // Pointer mode: move cursor on shared screen
  const handleStageMouseMove = (e: React.MouseEvent) => {
    if (!pointerMode || !sharerInfo) return;
    const now = Date.now();
    if (now - lastCursorSent.current < 50) return;
    lastCursorSent.current = now;
    const rect = stageRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    peer.sendCursor(Math.max(0, Math.min(1, x)), Math.max(0, Math.min(1, y)));
  };

  const handleStageClick = (e: React.MouseEvent) => {
    if (!sharerInfo) return;
    const rect = stageRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    // Control mode: send as control request (visible to host)
    if (controlMode && peer.allowControl && !peer.isScreenSharing) {
      peer.sendControlRequest(Math.max(0, Math.min(1, x)), Math.max(0, Math.min(1, y)));
    }
  };

  const handleStageLeave = () => {
    peer.sendCursor(-1, -1);
  };

  const copyRoomId = () => {
    navigator.clipboard.writeText(roomId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLeave = () => {
    peer.leave();
    onLeave();
  };

  const canUseControlMode = sharerInfo && peer.allowControl && !peer.isScreenSharing;

  return (
    <div className="h-screen bg-[#05050a] text-white flex flex-col overflow-hidden">
      {/* Header */}
      <header className="flex items-center justify-between px-5 py-3 border-b border-white/10 bg-[#0a0a12]/80 backdrop-blur">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-600 flex items-center justify-center shadow-lg shadow-violet-900/50 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="text-sm font-semibold flex items-center gap-2">
              Huddle Room
              {peer.status === "ready" && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              )}
            </div>
            <div className="text-xs text-white/50 flex items-center gap-2 flex-wrap">
              <span>Code:</span>
              <button
                onClick={copyRoomId}
                className="font-mono text-violet-300 hover:text-violet-200 flex items-center gap-1"
              >
                {roomId}
                <Copy className="w-3 h-3" />
                {copied && <span className="text-emerald-400">Copied!</span>}
              </button>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Users className="w-3 h-3" /> {allParticipants.length}
              </span>
              <span>·</span>
              <span className="capitalize text-white/40">{role}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setPointerMode((v) => !v)}
            disabled={!sharerInfo}
            title={sharerInfo ? "Toggle laser pointer" : "No one is sharing"}
            className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition border ${
              pointerMode
                ? "bg-amber-500/20 border-amber-400/50 text-amber-200"
                : "bg-white/5 border-white/10 hover:bg-white/10 text-white/70"
            } disabled:opacity-30 disabled:cursor-not-allowed`}
          >
            <MousePointer2 className="w-4 h-4" />
            <span className="hidden sm:inline">Pointer</span>
          </button>

          <button
            onClick={() => setControlMode((v) => !v)}
            disabled={!canUseControlMode}
            title={
              !sharerInfo
                ? "No one is sharing"
                : !peer.allowControl
                ? "Host hasn't enabled remote control"
                : peer.isScreenSharing
                ? "You are sharing"
                : "Toggle control mode"
            }
            className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition border ${
              controlMode
                ? "bg-sky-500/20 border-sky-400/50 text-sky-200"
                : "bg-white/5 border-white/10 hover:bg-white/10 text-white/70"
            } disabled:opacity-30 disabled:cursor-not-allowed`}
          >
            {controlMode ? <Shield className="w-4 h-4" /> : <ShieldOff className="w-4 h-4" />}
            <span className="hidden sm:inline">Control</span>
          </button>

          <button
            onClick={() => setSidebarOpen((v) => !v)}
            className="relative px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 bg-white/5 border border-white/10 hover:bg-white/10 text-white/70 transition"
          >
            <MessageSquare className="w-4 h-4" />
            <span className="hidden sm:inline">Panel</span>
          </button>
        </div>
      </header>

      {/* Main area */}
      <div className="flex-1 flex overflow-hidden">
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Banners */}
          {startError && (
            <div className="px-4 py-2 bg-amber-500/10 border-b border-amber-500/30 text-amber-200 text-sm">
              {startError}
            </div>
          )}
          {peer.status === "connecting" && (
            <div className="px-4 py-2 bg-violet-500/10 border-b border-violet-500/30 text-violet-200 text-sm">
              Connecting to signaling server...
            </div>
          )}
          {peer.error && (
            <div className="px-4 py-2 bg-red-500/10 border-b border-red-500/30 text-red-200 text-sm">
              {peer.error}
            </div>
          )}
          {peer.allowControl && !peer.isScreenSharing && sharerInfo && (
            <div className="px-4 py-2 bg-sky-500/10 border-b border-sky-500/30 text-sky-200 text-sm flex items-center gap-2">
              <Shield className="w-4 h-4" />
              The host has granted remote control — click on the shared screen to send actions.
            </div>
          )}
          {peer.isScreenSharing && peer.allowControl && (
            <div className="px-4 py-2 bg-emerald-500/10 border-b border-emerald-500/30 text-emerald-200 text-sm flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Remote control is active — participants can click on your shared screen.
            </div>
          )}

          {/* Stage */}
          <div className="flex-1 p-4 overflow-hidden flex flex-col gap-3">
            {sharerInfo ? (
              <>
                <div
                  ref={stageRef}
                  className={`relative flex-1 rounded-2xl overflow-hidden bg-black ring-1 ${
                    controlMode && canUseControlMode
                      ? "ring-sky-400/60 cursor-cell"
                      : pointerMode
                      ? "ring-amber-400/60 cursor-crosshair"
                      : "ring-white/10"
                  }`}
                  onMouseMove={handleStageMouseMove}
                  onMouseLeave={handleStageLeave}
                  onClick={handleStageClick}
                >
                  {sharerStream ? (
                    <video
                      autoPlay
                      playsInline
                      muted
                      ref={(el) => {
                        if (el) el.srcObject = sharerStream;
                      }}
                      className="w-full h-full object-contain bg-black"
                    />
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center text-white/40">
                      {sharerInfo.name} is starting their share...
                    </div>
                  )}

                  {/* Label */}
                  <div className="absolute top-3 left-3 flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/60 backdrop-blur text-white text-sm">
                    <Monitor className="w-4 h-4 text-emerald-400" />
                    {sharerInfo.name}'s screen
                    {peer.allowControl && (
                      <span className="text-[10px] ml-1 px-1.5 py-0.5 rounded bg-sky-500/30 text-sky-100 border border-sky-400/40">
                        CONTROL ON
                      </span>
                    )}
                  </div>

                  {/* Remote cursors */}
                  {Array.from(peer.cursors.values()).map((c) => (
                    <RemoteCursor key={c.peerId} cursor={c} />
                  ))}

                  {/* Control request markers */}
                  {peer.controlRequests.map((c, i) => (
                    <ControlMarker key={`${c.peerId}-${i}`} click={c} />
                  ))}

                  {/* Reactions */}
                  <ReactionsOverlay reactions={peer.reactions} />

                  {/* Status overlay bottom-right */}
                  <div className="absolute bottom-3 right-3 flex flex-col items-end gap-1.5">
                    {controlMode && canUseControlMode && (
                      <div className="px-2 py-1 rounded-md bg-sky-500/20 border border-sky-400/50 text-xs text-sky-100 flex items-center gap-1.5 backdrop-blur">
                        <Shield className="w-3 h-3" /> Clicking will send actions to host
                      </div>
                    )}
                    {pointerMode && (
                      <div className="px-2 py-1 rounded-md bg-amber-500/20 border border-amber-400/50 text-xs text-amber-100 flex items-center gap-1.5 backdrop-blur">
                        <MousePointer2 className="w-3 h-3" /> Your pointer is visible
                      </div>
                    )}
                  </div>
                </div>

                {/* Thumbnails */}
                {participantsWithoutSharer.length > 0 && (
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {participantsWithoutSharer.map((p) => (
                      <div key={p.info.id} className="w-48 shrink-0 relative">
                        <VideoTile
                          stream={p.stream}
                          info={p.info}
                          isLocal={p.isLocal}
                          color={p.color}
                        />
                        {p.info.isHandRaised && (
                          <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-amber-500 flex items-center justify-center text-lg shadow-lg animate-bounce">
                            ✋
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <div className={`flex-1 grid gap-3 auto-rows-fr ${gridClass(allParticipants.length)}`}>
                {allParticipants.map((p) => (
                  <div key={p.info.id} className="relative">
                    <VideoTile
                      stream={p.stream}
                      info={p.info}
                      isLocal={p.isLocal}
                      color={p.color}
                      isLarge={allParticipants.length <= 2}
                    />
                    {p.info.isHandRaised && (
                      <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center text-lg shadow-lg animate-bounce z-10">
                        ✋
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Control bar */}
          <div className="px-4 py-4 border-t border-white/10 bg-[#0a0a12]/80 backdrop-blur flex items-center justify-center gap-2 flex-wrap">
            <ControlButton
              onClick={peer.toggleMute}
              active={!peer.isMuted}
              activeIcon={<Mic className="w-5 h-5" />}
              inactiveIcon={<MicOff className="w-5 h-5" />}
              label={peer.isMuted ? "Unmute" : "Mute"}
            />
            <ControlButton
              onClick={peer.toggleVideo}
              active={!peer.isVideoOff}
              activeIcon={<Video className="w-5 h-5" />}
              inactiveIcon={<VideoOff className="w-5 h-5" />}
              label={peer.isVideoOff ? "Video on" : "Video off"}
            />
            <ControlButton
              onClick={async () => {
                if (peer.isScreenSharing) {
                  peer.stopScreenShare();
                } else {
                  await peer.startScreenShare();
                }
              }}
              active={peer.isScreenSharing}
              activeIcon={<MonitorUp className="w-5 h-5" />}
              inactiveIcon={<Monitor className="w-5 h-5" />}
              label={peer.isScreenSharing ? "Stop" : "Share"}
              accent={peer.isScreenSharing ? "green" : undefined}
            />

            {/* Host-only: allow control toggle when sharing */}
            {peer.isScreenSharing && role === "host" && (
              <ControlButton
                onClick={() => peer.toggleAllowControl(!peer.allowControl)}
                active={peer.allowControl}
                activeIcon={<Shield className="w-5 h-5" />}
                inactiveIcon={<ShieldOff className="w-5 h-5" />}
                label={peer.allowControl ? "Revoke" : "Allow control"}
                accent={peer.allowControl ? "blue" : undefined}
              />
            )}

            <ControlButton
              onClick={peer.toggleHand}
              active={peer.isHandRaised}
              activeIcon={<span className="text-lg">✋</span>}
              inactiveIcon={<Hand className="w-5 h-5" />}
              label={peer.isHandRaised ? "Lower" : "Raise"}
              accent={peer.isHandRaised ? "amber" : undefined}
            />

            {/* Reactions */}
            <ReactionBar onReact={peer.sendReaction} />

            <div className="w-px h-8 bg-white/10 mx-1" />
            <button
              onClick={handleLeave}
              className="px-5 py-3 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center gap-2 font-medium transition shadow-lg shadow-red-900/50"
              title="Leave room"
            >
              <Phone className="w-5 h-5 rotate-[135deg]" />
              <span className="hidden sm:inline">Leave</span>
            </button>
          </div>
        </div>

        {/* Sidebar */}
        {sidebarOpen && (
          <div className="w-80 shrink-0 hidden md:flex flex-col">
            <Sidebar
              tab={tab}
              onTabChange={setTab}
              onClose={() => setSidebarOpen(false)}
              messages={peer.messages}
              activity={peer.activity}
              participants={allParticipants}
              onSendChat={peer.sendChat}
              onClearHistory={peer.clearHistory}
              myName={myName}
              myId={peer.myId}
            />
          </div>
        )}
      </div>
    </div>
  );
}

function gridClass(count: number) {
  if (count <= 1) return "grid-cols-1";
  if (count <= 2) return "grid-cols-1 md:grid-cols-2";
  if (count <= 4) return "grid-cols-2";
  if (count <= 6) return "grid-cols-2 md:grid-cols-3";
  return "grid-cols-3 md:grid-cols-4";
}

interface ControlButtonProps {
  onClick: () => void;
  active: boolean;
  activeIcon: React.ReactNode;
  inactiveIcon: React.ReactNode;
  label: string;
  accent?: "green" | "blue" | "amber";
}

function ControlButton({ onClick, active, activeIcon, inactiveIcon, label, accent }: ControlButtonProps) {
  const base = "w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center transition shadow-lg";
  let bg = "bg-white/10 hover:bg-white/20 text-white border border-white/10";
  if (!active) bg = "bg-red-500/90 hover:bg-red-500 text-white border border-red-400/50";
  if (active && accent === "green") bg = "bg-emerald-500/90 hover:bg-emerald-500 text-white border border-emerald-400/50";
  if (active && accent === "blue") bg = "bg-sky-500/90 hover:bg-sky-500 text-white border border-sky-400/50";
  if (active && accent === "amber") bg = "bg-amber-500/90 hover:bg-amber-500 text-white border border-amber-400/50";

  return (
    <div className="flex flex-col items-center gap-1">
      <button onClick={onClick} className={`${base} ${bg}`} title={label}>
        {active ? activeIcon : inactiveIcon}
      </button>
      <span className="text-[10px] text-white/50 hidden sm:block">{label}</span>
    </div>
  );
}

function RemoteCursor({ cursor }: { cursor: CursorPayload }) {
  if (cursor.x < 0 || cursor.y < 0) return null;
  return (
    <div
      className="absolute pointer-events-none transition-all duration-75 ease-out z-20"
      style={{
        left: `${cursor.x * 100}%`,
        top: `${cursor.y * 100}%`,
        transform: "translate(-2px, -2px)",
      }}
    >
      <svg width="20" height="20" viewBox="0 0 24 24" style={{ filter: `drop-shadow(0 0 4px ${cursor.color})` }}>
        <path
          d="M3 2 L20 11 L12 13 L9 21 Z"
          fill={cursor.color}
          stroke="white"
          strokeWidth="1.5"
          strokeLinejoin="round"
        />
      </svg>
      <div
        className="absolute left-5 top-4 px-2 py-0.5 rounded-md text-xs font-medium whitespace-nowrap shadow-lg"
        style={{ backgroundColor: cursor.color, color: "white" }}
      >
        {cursor.name}
      </div>
    </div>
  );
}

function ControlMarker({ click }: { click: ClickPayload }) {
  return (
    <div
      className="absolute pointer-events-none z-20"
      style={{
        left: `${click.x * 100}%`,
        top: `${click.y * 100}%`,
        transform: "translate(-50%, -50%)",
      }}
    >
      <div
        className="w-14 h-14 rounded-full border-2 animate-ping"
        style={{ borderColor: click.color }}
      />
      <div
        className="absolute inset-0 m-auto w-4 h-4 rounded-full"
        style={{ backgroundColor: click.color }}
      />
      <div
        className="absolute left-8 top-1 px-2 py-0.5 rounded-md text-xs font-medium whitespace-nowrap shadow-lg"
        style={{ backgroundColor: click.color, color: "white" }}
      >
        {click.name} clicked
      </div>
    </div>
  );
}
