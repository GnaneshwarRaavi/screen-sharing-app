export type PeerRole = "host" | "guest";

export interface PeerInfo {
  id: string;
  name: string;
  hasVideo: boolean;
  hasAudio: boolean;
  isScreenSharing: boolean;
  isHost: boolean;
  isHandRaised: boolean;
}

export interface ChatMessage {
  id: string;
  sender: string;
  senderName: string;
  text: string;
  timestamp: number;
  system?: boolean;
}

export interface ActivityEvent {
  id: string;
  type:
    | "join"
    | "leave"
    | "share-start"
    | "share-stop"
    | "reaction"
    | "hand-raise"
    | "hand-lower"
    | "control-request"
    | "control-granted"
    | "control-revoked"
    | "mute"
    | "unmute";
  actor: string;
  actorName: string;
  detail?: string;
  timestamp: number;
}

export interface Reaction {
  id: string;
  peerId: string;
  name: string;
  emoji: string;
  timestamp: number;
}

export interface ControlRequest {
  peerId: string;
  name: string;
  x: number;
  y: number;
  color: string;
  timestamp: number;
}

export interface DataPayload {
  type:
    | "chat"
    | "cursor"
    | "click"
    | "meta"
    | "leave"
    | "reaction"
    | "hand"
    | "control-request"
    | "control-toggle"
    | "history-request"
    | "history-sync";
  payload: unknown;
}

export interface CursorPayload {
  peerId: string;
  name: string;
  x: number;
  y: number;
  color: string;
}

export interface ClickPayload {
  peerId: string;
  name: string;
  x: number;
  y: number;
  color: string;
  controlRequest?: boolean;
}

export interface MetaPayload {
  peerId: string;
  name: string;
  hasVideo: boolean;
  hasAudio: boolean;
  isScreenSharing?: boolean;
  isHost?: boolean;
  isHandRaised?: boolean;
}
