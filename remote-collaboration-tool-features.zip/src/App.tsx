import { useState } from "react";
import { Lobby } from "./components/Lobby";
import { Room } from "./components/Room";

interface SessionState {
  roomId: string;
  name: string;
  role: "host" | "guest";
}

export default function App() {
  const [session, setSession] = useState<SessionState | null>(null);

  if (!session) {
    return (
      <Lobby
        onJoin={(roomId, name, role) => setSession({ roomId, name, role })}
      />
    );
  }

  return (
    <Room
      roomId={session.roomId}
      myName={session.name}
      role={session.role}
      onLeave={() => setSession(null)}
    />
  );
}
