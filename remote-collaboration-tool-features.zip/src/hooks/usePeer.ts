import { useCallback, useEffect, useRef, useState } from "react";
import Peer, { DataConnection, MediaConnection } from "peerjs";
import type {
  ActivityEvent,
  ChatMessage,
  ClickPayload,
  CursorPayload,
  DataPayload,
  MetaPayload,
  PeerInfo,
  PeerRole,
  Reaction,
} from "../types";

interface RemotePeer {
  info: PeerInfo;
  stream: MediaStream | null;
  dataConn: DataConnection | null;
  mediaConn: MediaConnection | null;
}

interface UsePeerArgs {
  roomId: string;
  myName: string;
  role: PeerRole;
}

const CURSOR_COLORS = [
  "#f472b6", "#60a5fa", "#34d399", "#fbbf24",
  "#a78bfa", "#fb7185", "#22d3ee", "#f97316",
];

function pickColor(seed: string) {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  return CURSOR_COLORS[hash % CURSOR_COLORS.length];
}

export function generateRoomId() {
  return Math.random().toString(36).slice(2, 8).toUpperCase();
}

const MAX_HISTORY = 300;

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function saveToStorage<T>(key: string, value: T) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore quota */
  }
}

export function usePeer({ roomId, myName, role }: UsePeerArgs) {
  const peerRef = useRef<Peer | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const dataConnsRef = useRef<Map<string, DataConnection>>(new Map());
  const mediaConnsRef = useRef<Map<string, MediaConnection>>(new Map());
  const loggedJoinsRef = useRef<Set<string>>(new Set());

  const [status, setStatus] = useState<"connecting" | "ready" | "error">("connecting");
  const [error, setError] = useState<string>("");
  const [myId, setMyId] = useState<string>("");
  const [myColor] = useState<string>(() => pickColor(myName + Date.now()));
  const [peers, setPeers] = useState<Map<string, RemotePeer>>(new Map());
  const [messages, setMessages] = useState<ChatMessage[]>(() =>
    loadFromStorage<ChatMessage[]>(`huddle:chat:${roomId}`, [])
  );
  const [activity, setActivity] = useState<ActivityEvent[]>(() =>
    loadFromStorage<ActivityEvent[]>(`huddle:activity:${roomId}`, [])
  );
  const [reactions, setReactions] = useState<Reaction[]>([]);
  const [controlRequests, setControlRequests] = useState<ClickPayload[]>([]);
  const [cursors, setCursors] = useState<Map<string, CursorPayload>>(new Map());
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [allowControl, setAllowControl] = useState(false);

  const myIdRef = useRef("");
  const myNameRef = useRef(myName);
  const roleRef = useRef(role);
  myNameRef.current = myName;
  myIdRef.current = myId;

  // Persist chat & activity
  useEffect(() => {
    saveToStorage(`huddle:chat:${roomId}`, messages.slice(-MAX_HISTORY));
  }, [messages, roomId]);
  useEffect(() => {
    saveToStorage(`huddle:activity:${roomId}`, activity.slice(-MAX_HISTORY));
  }, [activity, roomId]);

  const updatePeer = useCallback((peerId: string, updater: (p: RemotePeer) => RemotePeer) => {
    setPeers((prev) => {
      const next = new Map(prev);
      const existing = next.get(peerId);
      if (existing) next.set(peerId, updater(existing));
      return next;
    });
  }, []);

  const broadcastData = useCallback((payload: DataPayload, exclude?: string) => {
    dataConnsRef.current.forEach((conn, id) => {
      if (id !== exclude && conn.open) {
        try { conn.send(payload); } catch { /* ignore */ }
      }
    });
  }, []);

  const logActivity = useCallback(
    (evt: Omit<ActivityEvent, "id" | "timestamp">) => {
      const entry: ActivityEvent = {
        ...evt,
        id: `${Date.now()}-${Math.random()}`,
        timestamp: Date.now(),
      };
      setActivity((prev) => [...prev, entry].slice(-MAX_HISTORY));
      // Broadcast to others
      broadcastData({ type: "reaction", payload: { __activity: entry } });
      return entry;
    },
    [broadcastData]
  );

  const addSystemMessage = useCallback((text: string) => {
    setMessages((prev) => [
      ...prev,
      {
        id: `${Date.now()}-${Math.random()}`,
        sender: "system",
        senderName: "System",
        text,
        timestamp: Date.now(),
        system: true,
      },
    ]);
  }, []);

  const clearHistory = useCallback(() => {
    setMessages([]);
    setActivity([]);
    localStorage.removeItem(`huddle:chat:${roomId}`);
    localStorage.removeItem(`huddle:activity:${roomId}`);
  }, [roomId]);

  const handleDataMessage = useCallback(
    (fromPeerId: string, data: DataPayload) => {
      switch (data.type) {
        case "chat": {
          const p = data.payload as { name: string; text: string };
          setMessages((prev) => [
            ...prev,
            {
              id: `${Date.now()}-${Math.random()}`,
              sender: fromPeerId,
              senderName: p.name,
              text: p.text,
              timestamp: Date.now(),
            },
          ]);
          break;
        }
        case "cursor": {
          const p = data.payload as CursorPayload;
          setCursors((prev) => {
            const next = new Map(prev);
            next.set(p.peerId, p);
            return next;
          });
          break;
        }
        case "click": {
          const p = data.payload as ClickPayload;
          if (p.controlRequest) {
            setControlRequests((prev) => [...prev.slice(-10), p]);
            // Auto-remove after 2.5s
            setTimeout(() => {
              setControlRequests((prev) => prev.filter((r) => r !== p));
            }, 2500);
          }
          break;
        }
        case "meta": {
          const p = data.payload as MetaPayload;
          updatePeer(fromPeerId, (peer) => ({
            ...peer,
            info: {
              ...peer.info,
              name: p.name,
              hasVideo: p.hasVideo,
              hasAudio: p.hasAudio,
              isScreenSharing: p.isScreenSharing ?? peer.info.isScreenSharing,
              isHost: p.isHost ?? peer.info.isHost,
              isHandRaised: p.isHandRaised ?? peer.info.isHandRaised,
            },
          }));
          break;
        }
        case "reaction": {
          const p = data.payload as (Reaction & { __activity?: ActivityEvent });
          if (p.__activity) {
            setActivity((prev) => [...prev, p.__activity!].slice(-MAX_HISTORY));
          } else {
            const r = p as Reaction;
            setReactions((prev) => [...prev, r]);
            setTimeout(() => {
              setReactions((prev) => prev.filter((x) => x.id !== r.id));
            }, 3500);
          }
          break;
        }
        case "hand": {
          const p = data.payload as { raised: boolean; name: string };
          updatePeer(fromPeerId, (peer) => ({
            ...peer,
            info: { ...peer.info, isHandRaised: p.raised },
          }));
          setActivity((prev) => [
            ...prev,
            {
              id: `${Date.now()}-${Math.random()}`,
              type: p.raised ? "hand-raise" : "hand-lower",
              actor: fromPeerId,
              actorName: p.name,
              timestamp: Date.now(),
            },
          ]);
          break;
        }
        case "control-toggle": {
          const p = data.payload as { allow: boolean };
          setAllowControl(p.allow);
          if (!p.allow) setControlRequests([]);
          setActivity((prev) => [
            ...prev,
            {
              id: `${Date.now()}-${Math.random()}`,
              type: p.allow ? "control-granted" : "control-revoked",
              actor: fromPeerId,
              actorName: "Host",
              timestamp: Date.now(),
            },
          ]);
          break;
        }
        case "history-request": {
          // Host responds with their history
          if (roleRef.current === "host") {
            const conn = dataConnsRef.current.get(fromPeerId);
            if (conn && conn.open) {
              conn.send({
                type: "history-sync",
                payload: {
                  messages: messagesRef.current.slice(-100),
                  activity: activityRef.current.slice(-100),
                },
              });
            }
          }
          break;
        }
        case "history-sync": {
          const p = data.payload as { messages: ChatMessage[]; activity: ActivityEvent[] };
          setMessages((prev) => {
            const merged = new Map<string, ChatMessage>();
            [...p.messages, ...prev].forEach((m) => merged.set(m.id, m));
            return Array.from(merged.values()).sort((a, b) => a.timestamp - b.timestamp);
          });
          setActivity((prev) => {
            const merged = new Map<string, ActivityEvent>();
            [...p.activity, ...prev].forEach((a) => merged.set(a.id, a));
            return Array.from(merged.values()).sort((a, b) => a.timestamp - b.timestamp);
          });
          break;
        }
        case "leave": {
          const leavingName = peers.get(fromPeerId)?.info.name || "Someone";
          setPeers((prev) => {
            const next = new Map(prev);
            next.delete(fromPeerId);
            return next;
          });
          dataConnsRef.current.delete(fromPeerId);
          mediaConnsRef.current.delete(fromPeerId);
          setCursors((prev) => {
            const next = new Map(prev);
            next.delete(fromPeerId);
            return next;
          });
          addSystemMessage(`${leavingName} left`);
          setActivity((prev) => [
            ...prev,
            {
              id: `${Date.now()}-${Math.random()}`,
              type: "leave",
              actor: fromPeerId,
              actorName: leavingName,
              timestamp: Date.now(),
            },
          ]);
          break;
        }
      }
    },
    [updatePeer, addSystemMessage, peers]
  );

  // Refs so handlers can read latest state
  const messagesRef = useRef<ChatMessage[]>([]);
  const activityRef = useRef<ActivityEvent[]>([]);
  messagesRef.current = messages;
  activityRef.current = activity;

  const setupDataConn = useCallback(
    (dataConn: DataConnection) => {
      const peerId = dataConn.peer;
      dataConnsRef.current.set(peerId, dataConn);

      dataConn.on("open", () => {
        dataConn.send({
          type: "meta",
          payload: {
            peerId: myIdRef.current,
            name: myNameRef.current,
            hasVideo: !isVideoOff,
            hasAudio: !isMuted,
            isHost: roleRef.current === "host",
            isHandRaised: isHandRaised,
          },
        } satisfies DataPayload);

        // Guests request history from host
        if (roleRef.current === "guest") {
          dataConn.send({ type: "history-request", payload: {} });
        }
      });

      dataConn.on("data", (raw) => handleDataMessage(peerId, raw as DataPayload));

      dataConn.on("close", () => {
        dataConnsRef.current.delete(peerId);
      });
    },
    [handleDataMessage, isMuted, isVideoOff, isHandRaised]
  );

  const setupMediaConn = useCallback(
    (peerId: string, mediaConn: MediaConnection) => {
      mediaConnsRef.current.set(peerId, mediaConn);
      if (localStreamRef.current) {
        try {
          if (mediaConn.peerConnection.getSenders().length === 0) {
            localStreamRef.current.getTracks().forEach((track) => {
              mediaConn.peerConnection.addTrack(track, localStreamRef.current!);
            });
          }
        } catch (e) {
          console.warn("addTrack error", e);
        }
      }

      mediaConn.on("stream", (remoteStream) => {
        setPeers((prev) => {
          const next = new Map(prev);
          const existing = next.get(peerId) || {
            info: {
              id: peerId,
              name: peerId.slice(0, 6),
              hasVideo: true,
              hasAudio: true,
              isScreenSharing: false,
              isHost: false,
              isHandRaised: false,
            },
            stream: null,
            dataConn: dataConnsRef.current.get(peerId) || null,
            mediaConn,
          };
          next.set(peerId, { ...existing, stream: remoteStream, mediaConn });
          return next;
        });
      });

      mediaConn.on("close", () => {
        mediaConnsRef.current.delete(peerId);
      });
    },
    []
  );

  // Initialize peer
  useEffect(() => {
    const peerId = role === "host" ? `huddle-${roomId}` : undefined;
    const peer = new Peer(peerId as string, {
      debug: 1,
      config: {
        iceServers: [
          { urls: "stun:stun.l.google.com:19302" },
          { urls: "stun:global.stun.twilio.com:3478" },
        ],
      },
    });
    peerRef.current = peer;

    peer.on("open", (id) => {
      setMyId(id);
      setStatus("ready");
    });

    peer.on("error", (err) => {
      console.error("peer error", err);
      setError(err.type + ": " + err.message);
      if (err.type === "unavailable-id") {
        setError("This room is already active. Try a different code or wait a moment.");
      }
      setStatus("error");
    });

    peer.on("connection", (dataConn) => {
      const peerId = dataConn.peer;
      setPeers((prev) => {
        const next = new Map(prev);
        next.set(peerId, {
          info: {
            id: peerId,
            name: peerId.slice(0, 6),
            hasVideo: true,
            hasAudio: true,
            isScreenSharing: false,
            isHost: false,
            isHandRaised: false,
          },
          stream: null,
          dataConn,
          mediaConn: null,
        });
        return next;
      });
      setupDataConn(dataConn);
    });

    peer.on("call", (mediaConn) => {
      mediaConn.answer(localStreamRef.current || undefined);
      setupMediaConn(mediaConn.peer, mediaConn);
    });

    return () => {
      peer.destroy();
      localStreamRef.current?.getTracks().forEach((t) => t.stop());
      cameraStreamRef.current?.getTracks().forEach((t) => t.stop());
      screenStreamRef.current?.getTracks().forEach((t) => t.stop());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roomId, role]);

  // Watch for new peers (data conn opened) and host initiates call
  useEffect(() => {
    if (role !== "host") return;
    peers.forEach((p, peerId) => {
      if (p.dataConn && !p.mediaConn && peerRef.current && localStreamRef.current) {
        // Wait a tick for data conn to be fully open
        setTimeout(() => {
          try {
            const call = peerRef.current!.call(peerId, localStreamRef.current!);
            setupMediaConn(peerId, call);
            // Log join on first connect
            if (!loggedJoinsRef.current.has(peerId)) {
              loggedJoinsRef.current.add(peerId);
              addSystemMessage(`${p.info.name} joined`);
              setActivity((prev) => [
                ...prev,
                {
                  id: `${Date.now()}-${Math.random()}`,
                  type: "join",
                  actor: peerId,
                  actorName: p.info.name,
                  timestamp: Date.now(),
                },
              ]);
            }
          } catch (e) {
            console.warn("call failed", e);
          }
        }, 200);
      }
    });
  }, [peers, role, setupMediaConn, addSystemMessage]);

  // Guest: when ready, connect to host
  useEffect(() => {
    if (role !== "guest" || status !== "ready" || !peerRef.current) return;
    const hostId = `huddle-${roomId}`;

    const dataConn = peerRef.current.connect(hostId, { reliable: false });
    setPeers((prev) => {
      const next = new Map(prev);
      next.set(hostId, {
        info: {
          id: hostId,
          name: "Host",
          hasVideo: true,
          hasAudio: true,
          isScreenSharing: false,
          isHost: true,
          isHandRaised: false,
        },
        stream: null,
        dataConn,
        mediaConn: null,
      });
      return next;
    });
    setupDataConn(dataConn);

    const call = peerRef.current.call(hostId, localStreamRef.current || new MediaStream());
    setupMediaConn(hostId, call);
    addSystemMessage("Connecting to room...");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, role]);

  // ---- Actions ----

  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      cameraStreamRef.current = stream;
      localStreamRef.current = stream;
      mediaConnsRef.current.forEach((mc) => {
        stream.getTracks().forEach((track) => {
          const sender = mc.peerConnection.getSenders().find((s) => s.track?.kind === track.kind);
          if (sender) sender.replaceTrack(track);
          else mc.peerConnection.addTrack(track, stream);
        });
      });
      return true;
    } catch (err) {
      console.error("camera error", err);
      setError("Couldn't access camera/mic. Check browser permissions.");
      return false;
    }
  }, []);

  const broadcastMeta = useCallback(() => {
    broadcastData({
      type: "meta",
      payload: {
        peerId: myIdRef.current,
        name: myNameRef.current,
        hasVideo: !isVideoOff,
        hasAudio: !isMuted,
        isScreenSharing,
        isHost: roleRef.current === "host",
        isHandRaised,
      },
    });
  }, [broadcastData, isMuted, isVideoOff, isScreenSharing, isHandRaised]);

  const toggleMute = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    stream.getAudioTracks().forEach((t) => (t.enabled = isMuted));
    setIsMuted((v) => !v);
    setActivity((prev) => [
      ...prev,
      {
        id: `${Date.now()}-${Math.random()}`,
        type: isMuted ? "unmute" : "mute",
        actor: myIdRef.current,
        actorName: myNameRef.current,
        timestamp: Date.now(),
      },
    ]);
    setTimeout(broadcastMeta, 0);
  }, [isMuted, broadcastMeta]);

  const toggleVideo = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    stream.getVideoTracks().forEach((t) => (t.enabled = isVideoOff));
    setIsVideoOff((v) => !v);
    setTimeout(broadcastMeta, 0);
  }, [isVideoOff, broadcastMeta]);

  const startScreenShare = useCallback(async () => {
    try {
      const screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 30 } as MediaTrackConstraints,
        audio: false,
      });
      screenStreamRef.current = screenStream;
      const screenTrack = screenStream.getVideoTracks()[0];

      mediaConnsRef.current.forEach((mc) => {
        const sender = mc.peerConnection.getSenders().find((s) => s.track?.kind === "video");
        if (sender) sender.replaceTrack(screenTrack);
      });

      localStreamRef.current = new MediaStream([
        screenTrack,
        ...(cameraStreamRef.current?.getAudioTracks() || []),
      ]);

      setIsScreenSharing(true);
      setActivity((prev) => [
        ...prev,
        {
          id: `${Date.now()}-${Math.random()}`,
          type: "share-start",
          actor: myIdRef.current,
          actorName: myNameRef.current,
          timestamp: Date.now(),
        },
      ]);
      addSystemMessage(`You started sharing your screen`);
      broadcastMeta();

      screenTrack.onended = () => {
        stopScreenShare();
      };

      return true;
    } catch (err) {
      console.error("screen share error", err);
      return false;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [broadcastMeta, addSystemMessage]);

  const stopScreenShare = useCallback(() => {
    const screenStream = screenStreamRef.current;
    screenStream?.getTracks().forEach((t) => t.stop());
    screenStreamRef.current = null;

    const cameraTrack = cameraStreamRef.current?.getVideoTracks()[0];
    if (cameraTrack) {
      mediaConnsRef.current.forEach((mc) => {
        const sender = mc.peerConnection.getSenders().find((s) => s.track?.kind === "video");
        if (sender) sender.replaceTrack(cameraTrack);
      });
    }

    localStreamRef.current = cameraStreamRef.current;
    setIsScreenSharing(false);
    setAllowControl(false);
    setControlRequests([]);
    setActivity((prev) => [
      ...prev,
      {
        id: `${Date.now()}-${Math.random()}`,
        type: "share-stop",
        actor: myIdRef.current,
        actorName: myNameRef.current,
        timestamp: Date.now(),
      },
    ]);
    addSystemMessage(`You stopped sharing`);
    broadcastMeta();
    broadcastData({ type: "control-toggle", payload: { allow: false } });
  }, [broadcastMeta, broadcastData, addSystemMessage]);

  const toggleAllowControl = useCallback(
    (allow: boolean) => {
      setAllowControl(allow);
      if (!allow) setControlRequests([]);
      broadcastData({ type: "control-toggle", payload: { allow } });
      setActivity((prev) => [
        ...prev,
        {
          id: `${Date.now()}-${Math.random()}`,
          type: allow ? "control-granted" : "control-revoked",
          actor: myIdRef.current,
          actorName: myNameRef.current,
          timestamp: Date.now(),
        },
      ]);
    },
    [broadcastData]
  );

  const sendChat = useCallback(
    (text: string) => {
      if (!text.trim()) return;
      const msg: ChatMessage = {
        id: `${Date.now()}-${Math.random()}`,
        sender: "me",
        senderName: myNameRef.current,
        text,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, msg]);
      broadcastData({ type: "chat", payload: { name: myNameRef.current, text } });
    },
    [broadcastData]
  );

  const sendCursor = useCallback(
    (x: number, y: number) => {
      broadcastData({
        type: "cursor",
        payload: { peerId: myIdRef.current, name: myNameRef.current, x, y, color: myColor },
      });
    },
    [broadcastData, myColor]
  );

  const sendControlRequest = useCallback(
    (x: number, y: number) => {
      broadcastData({
        type: "click",
        payload: {
          peerId: myIdRef.current,
          name: myNameRef.current,
          x,
          y,
          color: myColor,
          controlRequest: true,
        },
      });
      setActivity((prev) => [
        ...prev,
        {
          id: `${Date.now()}-${Math.random()}`,
          type: "control-request",
          actor: myIdRef.current,
          actorName: myNameRef.current,
          detail: `(${Math.round(x * 100)}%, ${Math.round(y * 100)}%)`,
          timestamp: Date.now(),
        },
      ]);
    },
    [broadcastData, myColor]
  );

  const sendReaction = useCallback(
    (emoji: string) => {
      const r: Reaction = {
        id: `${Date.now()}-${Math.random()}`,
        peerId: myIdRef.current,
        name: myNameRef.current,
        emoji,
        timestamp: Date.now(),
      };
      setReactions((prev) => [...prev, r]);
      setTimeout(() => {
        setReactions((prev) => prev.filter((x) => x.id !== r.id));
      }, 3500);
      broadcastData({ type: "reaction", payload: r });
      setActivity((prev) => [
        ...prev,
        {
          id: `${Date.now()}-${Math.random()}`,
          type: "reaction",
          actor: myIdRef.current,
          actorName: myNameRef.current,
          detail: emoji,
          timestamp: Date.now(),
        },
      ]);
    },
    [broadcastData]
  );

  const toggleHand = useCallback(() => {
    const next = !isHandRaised;
    setIsHandRaised(next);
    broadcastData({ type: "hand", payload: { raised: next, name: myNameRef.current } });
    setActivity((prev) => [
      ...prev,
      {
        id: `${Date.now()}-${Math.random()}`,
        type: next ? "hand-raise" : "hand-lower",
        actor: myIdRef.current,
        actorName: myNameRef.current,
        timestamp: Date.now(),
      },
    ]);
  }, [isHandRaised, broadcastData]);

  const leave = useCallback(() => {
    broadcastData({ type: "leave", payload: {} });
    peerRef.current?.destroy();
    localStreamRef.current?.getTracks().forEach((t) => t.stop());
    cameraStreamRef.current?.getTracks().forEach((t) => t.stop());
    screenStreamRef.current?.getTracks().forEach((t) => t.stop());
  }, [broadcastData]);

  return {
    status,
    error,
    myId,
    myColor,
    peers,
    messages,
    activity,
    reactions,
    controlRequests,
    cursors,
    isMuted,
    isVideoOff,
    isScreenSharing,
    isHandRaised,
    allowControl,
    role,
    localStream: localStreamRef.current,
    startCamera,
    toggleMute,
    toggleVideo,
    startScreenShare,
    stopScreenShare,
    toggleAllowControl,
    sendChat,
    sendCursor,
    sendControlRequest,
    sendReaction,
    toggleHand,
    leave,
    clearHistory,
    broadcastMeta,
    addSystemMessage,
    logActivity,
  };
}


